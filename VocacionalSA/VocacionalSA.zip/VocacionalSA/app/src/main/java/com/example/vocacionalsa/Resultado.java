package com.example.vocacionalsa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Resultado extends AppCompatActivity {
    static int P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14;;
    TextView valorj;
    int resultado;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        getSupportActionBar().hide();
        valorj = findViewById(R.id.carioca);
        resultado = P1 + P2 + P3 + P4 + P5 + P6 + P7 + P8 + P9 + P10 + P11 + P12 + P13 + P14;

    }

    public void Calcpontuacao(View view) {
        if (resultado >= 75 && resultado < 100) {
            valorj.setText("Perfil1");
        } else if (resultado >= 100 && resultado < 159) {
            valorj.setText("Perfil2");
        } else if (resultado >= 160 && resultado < 225) {
            valorj.setText("Perfil3");
        } else {
            valorj.setText("AAAAAA");
        }

    }

}
